package com.gc.restassured.Tests;
import java.util.List;

import com.gc.restassured.SupportedUtils.SQLWrapper;
import com.gc.restassured.SupportedUtils.lib;

import java.util.HashMap;

public class TestMysql {
	public static void main(String[] args) throws Exception {

		//delete row
		String sDbQuery="delete  from PG_Transactions where id ='400'";
		SQLWrapper.modifyDataIntoDB(sDbQuery,"Delete");
		
		//Insert row
		String sInsertQuery="insert into PG_Transactions values(400,'20171017101523000151_2','UI20171017054313524','TMS_DRAFTY','Pull',80.00,'Approved',80,'2017-10-17 05:45:23',0)";
		SQLWrapper.modifyDataIntoDB(sInsertQuery,"Insert");
		
		//verify select query response
		String sDBQuery="select agreement_no from PG_Transactions where id ='400'";
		List<HashMap> list = SQLWrapper.getResultSet(sDBQuery);
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
			System.out.println(list.get(i).get("agreement_no"));
		}
		
		SQLWrapper.closeMySqlConnection();
		
	}
		

}
