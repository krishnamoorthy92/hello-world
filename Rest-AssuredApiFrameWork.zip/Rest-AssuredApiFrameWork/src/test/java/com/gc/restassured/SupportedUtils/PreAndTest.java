package com.gc.restassured.SupportedUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

public  class PreAndTest extends HTMLReporter{
	
	
	@BeforeSuite
	public void beforeSuite() throws Exception {
		startReport();
		switch (lib.configData.getProperty("ENVIRONMENT").trim()) {
		case "BASE_ENVIRONMENT":
			MongoDBWrapper.createCollection(lib.configData.getProperty("MongoCollectionName"));
			SQLWrapper.modifyDataIntoDB(Constants.TRUNCATE_MYSQL_EMULATOR_WORLSPAY_ORDER_TABLE,"TRUNCATE");
			break;
		case "EMULATOR_ENVIRONMENT":
			System.out.println("Running suite in emulator environment so not performing any prerequite  steps in database");
			break;
		}
	}
	
	@BeforeClass
	public void beforeClass() {
		startTestCase(testSuiteName, testSuiteDescription);		
	}

	@AfterMethod
	public void afterMethod() {
	}

	@AfterSuite 
	public void afterSuite() throws Exception {
		endResult();
		try{
			MongoDBWrapper.closeMongoDbconnection();
		}catch(Exception Ex){
			SQLWrapper.closeMySqlConnection();
		}
	}

	@Override
	public long takeSnap() {
		// TODO Auto-generated method stub
		return 0;
	}
}
