package com.gc.restassured.Tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.gc.restassured.SupportedUtils.MongoDBWrapper;
import com.gc.restassured.SupportedUtils.lib;

public class TestMongo {

	public static void main(String[] args) throws Exception {
		Logger logger = Logger.getLogger(TestMongo.class);
		
		// inserting multiple document
		ArrayList<String> jsonList = new ArrayList();
		jsonList.add("{name:'jamess',value:5}");
		jsonList.add("{name:'pennys',value:'Worths'}");
		MongoDBWrapper.InsertMultiDocuments("pg_transactions", jsonList);
		
		/**
		// inserting the single document
		String jsonString = "{name:'ApiTestin',value:'Restassured'}";
		MongoDBWrapper.InsertOneDocument("pg_transactions", jsonString);
		
		// dropping/create/insert document
		MongoDBWrapper.dropCollection("pg_transactions");
		String jsonAddString = "{name:'ApiTestindf',value:112550166}";
		MongoDBWrapper.InsertOneDocument("pg_transactions", jsonAddString);

		// get the records
		String query = "{name:'ApiTestindf'}";
		List<HashMap> result = MongoDBWrapper.getRecords("pg_transactions", query);
		System.out.println("Retrived result are:" + result);
		Object digit = result.get(0).get("value");
		BigDecimal tranid = new BigDecimal(String.valueOf(digit));
		System.out.println("The Transaction id is :" + tranid);
		// end of getting the records
		 * 
		 */
	}

}
