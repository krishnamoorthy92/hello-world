package com.gc.restassured.SupportedUtils;

public class Constants {
	public static final String RESOURCE_DIR = "./src/test/resources/";
	public static final String DATAINPUT_DIR="./src/test/resources/API/";
	public static final String AUTH_USERNAME="admin";
	public static final String AUTH_PASSWORD="admin";
	public static final String JSON_CONTENTTYPE="application/json";
	public static final String PG3_TRANSACTION_EMULATOR_URL="http://192.168.56.102:8283/api/v1.0/payment/transactions/";
	public static final String PG3_TRANSACTION_BASE_URL="https://192.168.56.104:7001/api/v1.0/payment/transactions/";
	public static final String TRUNCATE_MYSQL_EMULATOR_WORLSPAY_ORDER_TABLE="TRUNCATE TABLE worldpay_order";


}
