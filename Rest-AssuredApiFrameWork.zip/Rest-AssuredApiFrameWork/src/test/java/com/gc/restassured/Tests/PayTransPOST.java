package com.gc.restassured.Tests;

import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.gc.restassured.CoreUtils.BusinessFunction;
import com.gc.restassured.SupportedUtils.Constants;
import com.gc.restassured.SupportedUtils.ExcelUtil;
import com.gc.restassured.SupportedUtils.lib;

import io.restassured.response.Response;

public class PayTransPOST extends BusinessFunction {
	String fileName = "Payment_Transaction";
	HashMap<String, String> testData;
	Map<String, String> headers = new HashMap<String, String>();
	Response response;

	@BeforeTest
	public void setValues() {
		try {
			testSuiteName = "PG3.0 Transaction Post Request ";
			testSuiteDescription = "Validating Payment Gateway 3.0 Transaction Post Request";
		} catch (Exception e) {
			e.printStackTrace();
			reportRequest("Exception occured in @BeforeTest Method while reading the TestDescription", "FAIL");
		}
	}

	@DataProvider(name = "TransactionPost")
	public Object[][] TransactionPostProvider() throws Exception {
		String query = "select TestName from " + getClass().getSimpleName() + " where ExecutionFlag ='Y'";
		Object[][] testData = ExcelUtil.GetExcelDataHash1(fileName, query);
		System.out.println(Arrays.deepToString(testData));
		return testData;
	}

	@Test(dataProvider = "TransactionPost")
	public void createTransPostRequest(String testName) {
		try {
			lib.testName.set(testName);
			svcTest = startTestModule(lib.testName.get());
			svcTest.assignAuthor("Govind");
			svcTest.assignCategory("SmokeAPI");
			testData = ExcelUtil.getRequestParams(fileName, getClass().getSimpleName(), lib.testName.get());

			// set header
			headers.put("uid", "test");

			if (lib.configData.getProperty("ENVIRONMENT").trim().equals("BASE_ENVIRONMENT")) {
				// Post the request
				response = postWithHeaderAndForm(headers, testData.get("PAYLOAD_BODY"),
						Constants.PG3_TRANSACTION_BASE_URL);
			} else {
				response = postWithHeaderAndForm(headers, testData.get("PAYLOAD_BODY"),
						Constants.PG3_TRANSACTION_EMULATOR_URL);
				System.out.println("PG3_TRANSACTION_EMULATOR_URL :" + Constants.PG3_TRANSACTION_EMULATOR_URL);
			}
			
			// Verify the Content by Specific Key
			verifyContentWithKey(response, testData.get("RESPONSE_KEY"), testData.get("RESPONSE_MESSAGE"));

			// Verify the response status code
			verifyResponseCode(response, testData.get("RESPONSE_CODE"));

			// Verify the Content type
			verifyContentType(response, testData.get("RESPONSE_CONTENTTYPE"));

			// Verify the response time
			verifyResponseTime(response, 1000);

			//Checking weather Suite needs to run in base_Environment or Emulator Environment
			switch (lib.configData.getProperty("ENVIRONMENT").trim()) {

			case "BASE_ENVIRONMENT":
				// Verify Db response
				if (!testData.get("MONGOPOSTDBQUERY").isEmpty()) {
					verifyMongoDocumentValue(lib.configData.getProperty("MongoCollectionName"),
							testData.get("MONGOPOSTDBQUERY"), testData.get("MONGODBRESPONSEKEY"),
							testData.get("MONGODBRESPONSEVALUE"));
				}
				break;

			case "EMULATOR_ENVIRONMENT":
				reportRequest("Running suite in emulator environment so not validating in database", "INFO");
				break;
			}

		} catch (Exception e) {
			reportRequest("Exception occured while executing the @Test method" + e.getMessage(), "FAIL");
		}
	}

}
